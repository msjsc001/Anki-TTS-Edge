"""Version information for the edge_tts package."""

__version__ = "7.0.0"
__version_info__ = tuple(int(num) for num in __version__.split("."))
